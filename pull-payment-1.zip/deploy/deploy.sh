
source $1.env

if [ "$1" = "eth" ]; then
    echo "Deploying to Ethereum Mainnet"
    echo "RPC URL: $RPC"
    echo "Chain ID: $CHAIN_ID"
    echo "Gas Price: $GAS_PRICE"
    echo "Etherscan API Key: $SCAN_API_KEY"
    forge create --rpc-url $RPC -i src/PullPaymentFactory.sol:PullPaymentFactory \
        --optimize --optimizer-runs 20000 \
        --legacy \
        --etherscan-api-key $SCAN_API_KEY \
		--broadcast \
        --gas-price $GAS_PRICE \
        --verify
else
    echo "Deploying to $1"
    echo "RPC URL: $RPC"
    echo "Chain ID: $CHAIN_ID"
    echo "Etherscan API Key: $SCAN_API_KEY"
    echo "Etherscan API URL: $SCAN_API_URL"


    forge create --rpc-url $RPC -i src/PullPaymentFactory.sol:PullPaymentFactory \
        --optimize --optimizer-runs 20000 \
        --legacy \
        --etherscan-api-key $SCAN_API_KEY \
        --verifier-url $SCAN_API_URL \
		--broadcast \
        --verify
fi
