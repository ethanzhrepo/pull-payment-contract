#!/bin/bash

source $1.env


CONTRACT_ADDRESS=0x995E14C1bf9FF2F6Ab296e1670e44e7Ec069795D

OWNER_ADDRESS=0xD6aeD9606C6Ee485455677D3932487243a3B746F
CASHER_ADDRESS=0x88839174b85fF0b6F76a98542d4807C26B15011C
TO_ADDRESS=0x89f4c5BBf5BEBf9A84207f7dDEdd49138f08B288


CONSTRUCTOR_ARGS=$(cast abi-encode "constructor(address,address,address)" $OWNER_ADDRESS $CASHER_ADDRESS $TO_ADDRESS)


if [ "$1" = "eth" ]; then
    forge verify-contract --chain-id $CHAIN_ID \
        --constructor-args $CONSTRUCTOR_ARGS \
        --etherscan-api-key  $SCAN_API_KEY \
        --watch $CONTRACT_ADDRESS src/PullPayment.sol:PullPayment
else
    forge verify-contract --chain-id $CHAIN_ID \
        --constructor-args $CONSTRUCTOR_ARGS \
        --etherscan-api-key $SCAN_API_KEY \
        --verifier-url $SCAN_API_URL \
        --watch $CONTRACT_ADDRESS src/PullPayment.sol:PullPayment
fi