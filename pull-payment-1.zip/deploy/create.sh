#!/bin/bash

source $1.env

PULL_PAYMENT_FACTORY="0xBd315E617855990fede6024264d1Db9b8DB3E9d8"

OWNER="0xD6aeD9606C6Ee485455677D3932487243a3B746F"
CASHER="0x88839174b85fF0b6F76a98542d4807C26B15011C"
TO_ADDRESS="0x89f4c5BBf5BEBf9A84207f7dDEdd49138f08B288"



# Generate a random salt if not provided
# SALT="0x$(openssl rand -hex 32)"
# echo "SALT: $SALT"
SALT="0x9a19b8147c55e6e89343fbc9fc1f28177d4d5ced62e305512a4a0c3f7a0955d6"

# Check if --onlyAddress flag is provided
if [[ "$2" == "--onlyAddress" ]]; then
    # Only display the calculated address
    cast call $PULL_PAYMENT_FACTORY "computePullPaymentAddress(address,address,address,bytes32)(address)" $OWNER $CASHER $TO_ADDRESS $SALT \
         --rpc-url $RPC 
else
    # Execute deployment
    echo "Deploying Pull Payment contract with salt: $SALT"
    echo "Please enter your private key:"
    read -s PRIVATE_KEY
    
    # Deploy the contract
    TX=$(cast send --private-key $PRIVATE_KEY \
        --rpc-url $RPC \
        $PULL_PAYMENT_FACTORY \
        "createPullPayment(address,address,address,bytes32)(address)" \
        $OWNER $CASHER $TO_ADDRESS $SALT)
    echo "Transaction: $TX"
fi

# 0x9a19b8147c55e6e89343fbc9fc1f28177d4d5ced62e305512a4a0c3f7a0955d6