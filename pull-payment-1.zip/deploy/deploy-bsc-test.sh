
source bsc-test.env

forge create --rpc-url $RPC -i src/PullPaymentFactory.sol:PullPaymentFactory \
    --optimize --optimizer-runs 20000 \
    --legacy \
    --broadcast
