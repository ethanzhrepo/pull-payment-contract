#!/bin/bash

source $1.env

CONTRACT_ADDRESS=0xBd315E617855990fede6024264d1Db9b8DB3E9d8


if [ "$1" = "eth" ]; then
    forge verify-contract --chain-id $CHAIN_ID \
        --etherscan-api-key $SCAN_API_KEY \
        --watch $CONTRACT_ADDRESS src/PullPaymentFactory.sol:PullPaymentFactory
else
    forge verify-contract --chain-id $CHAIN_ID \
        --etherscan-api-key $SCAN_API_KEY \
        --verifier-url $SCAN_API_URL \
        --watch $CONTRACT_ADDRESS src/PullPaymentFactory.sol:PullPaymentFactory
fi